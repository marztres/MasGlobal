﻿export class EmployeeData {

}